module com.soluzione_2023_07_18 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.soluzione_2023_07_18 to javafx.fxml;
    exports com.soluzione_2023_07_18;
}