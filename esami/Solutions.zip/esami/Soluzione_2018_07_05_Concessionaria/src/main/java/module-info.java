module com.soluzione_2018_07_05 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.soluzione_2018_07_05 to javafx.fxml;
    exports com.soluzione_2018_07_05;
}