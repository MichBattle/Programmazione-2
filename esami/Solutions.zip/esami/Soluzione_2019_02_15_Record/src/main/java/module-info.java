module com.soluzione_2019_02_15 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.soluzione_2019_02_15 to javafx.fxml;
    exports com.soluzione_2019_02_15;
}