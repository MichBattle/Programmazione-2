module org.example.soluzione_2019_01_18 {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.soluzione_2019_01_18 to javafx.fxml;
    exports org.example.soluzione_2019_01_18;
}