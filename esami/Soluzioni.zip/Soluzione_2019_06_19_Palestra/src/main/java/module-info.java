module org.example.soluzione_2019_06_19 {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.soluzione_2019_06_19 to javafx.fxml;
    exports org.example.soluzione_2019_06_19;
}