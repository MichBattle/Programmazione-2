module com.soluzione_2024_07_08 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.soluzione_2024_07_08 to javafx.fxml;
    exports com.soluzione_2024_07_08;
}