package Model;

/**
 * contiene tutti i tipi di mostri presenti nel testo
 */
public enum Mostro {
    Drowners,
    Wolves,
    Foglet
}
