package Model;

public enum Semi {
    CUORI,
    FIORI,
    PICCHE,
    QUADRI,
    J
}
