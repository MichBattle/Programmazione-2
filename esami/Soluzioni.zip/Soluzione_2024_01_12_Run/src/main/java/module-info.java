module org.example.soluzione_2024_01_12 {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.soluzione_2024_01_12 to javafx.fxml;
    exports org.example.soluzione_2024_01_12;
}