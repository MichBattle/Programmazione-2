module org.example.soluzione_2024_06_17_evocazioni {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.soluzione_2024_06_17_evocazioni to javafx.fxml;
    exports org.example.soluzione_2024_06_17_evocazioni;
}